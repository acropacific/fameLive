--------------------------------------------------------------------------------

                                JUV RTMP Client version 1.5.16


Readme and Quick Manual

                       Copyright (c) 2007-2011 Smaxe Ltd. All Rights Reserved.
--------------------------------------------------------------------------------

CONTENTS
1. Release Notes
2. Getting Started
3. Known Issues
4. Support
5. Legal Information
6. Contact

================================================================================
1. RELEASE NOTES

JUV RTMP Client is a lightweight library that provides RTMP/RTMPT-enabled server
access API for Java applications.

Features

 - RTMP/RTMPT/RTMPS/RTMPE/RTMPTE protocols support (both AMF0 and AMF3 encodings)
 - remote method invocation
 - remote shared object management
 - play and publish audio/video streams
 - ActionScript flash.net.* alike classes and methods
 - Proxy support
 - Java5 or later compatible

1.1 Recent Changes
==================

Changes in 1.5 (2010-02-01):

 - Maintenance release
 - Minor improvements, bug fixes


Changes in 1.4 (2009-02-01)

 - Added RTMPE/RTMPTE protocols support
 - Added Proxy support
 - Minor improvements


Changes in 1.3 (2008-11-01)

 - Introduced Java varargs instead of Object[]
 - Minor improvements


Changes in 1.2 (2008-09-22)

 - Added 'Developer Guide' to the distribution package
 - Added RTMPS support
 - Added buffered output for the FlvVideo class
 - Minor improvements


Changes in 1.1 (2008-07-28)

 - Added FlvVideo class: it can save playing stream to the flv file
 - Added MediaStreamController and FlvFileMediaStream classes: it can publish flv file as a live video stream
 - Added support of the FlvData RTMP packet
 - Minor improvements

================================================================================
2. GETTING STARTED

The JUV RTMP Client distribution package contains the following:

 - JUV RTMP Client Library (@product.uv.client.version@)
 - JUV RTMP Client JavaDocs
 - JUV RTMP Client Developer Guide
 - JUV RTMP Client usage examples source code
 - JUV RTMP Client License file (License.txt)
 - This Readme file (Readme.txt)

Installing Library JAR Files
----------------------------
JUV RTMP Client library has a single jar (no dependencies) which should be placed in the application class path.

================================================================================
3. KNOWN ISSUES

================================================================================
4. SUPPORT

If you experience a problem or find a bug, please submit us an issue using 
e-mail:  support@smaxe.com.

================================================================================
5. LEGAL INFORMATION

Licensing
---------

Please be sure to read carefully the license agreement document supplied with
the product in the license.txt file.

================================================================================
6. CONTACT

Smaxe Ltd.
E-mail : info@smaxe.com, or
Web : http://www.smaxe.com