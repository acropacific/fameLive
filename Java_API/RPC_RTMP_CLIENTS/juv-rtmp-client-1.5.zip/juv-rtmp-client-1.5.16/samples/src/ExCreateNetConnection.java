/**
 * Copyright (c) 2006 - 2008 Smaxe Ltd (www.smaxe.com).
 * All rights reserved.
 */

import com.smaxe.uv.Responder;
import com.smaxe.uv.client.INetConnection;
import com.smaxe.uv.client.License;
import com.smaxe.uv.client.NetConnection;

import java.util.Map;

/**
 * <code>ExCreateNetConnection</code> - {@link NetConnection} usage example.
 * <p> Note: The example shows how to create, configure, set callback object and connect
 * to the server.
 * 
 * @author Andrei Sochirca
 */
public final class ExCreateNetConnection extends Object
{
    /**
     * Entry point.
     * 
     * @param args
     * @throws Exception 
     */
    public static void main(final String[] args) throws Exception
    {
        // NOTE:
        // you can get Evaluation Key at:
        // http://www.smaxe.com/order.jsf#request_evaluation_key
        // or buy at:
        // http://www.smaxe.com/order.jsf
        License.setKey("SET-YOUR-KEY");
        
        final NetConnection connection = new NetConnection();
        
        // configure NetConnection
        connection.configuration().put(NetConnection.Configuration.INACTIVITY_TIMEOUT, 30 /*seconds*/);
        
        connection.client(new ClientHandler());
        
        connection.addEventListener(new NetConnectionListener());
        
        connection.connect("rtmp://localhost:1935/app");
    }
    
    
    /**
     * <code>ClientHandler</code> - server invokes methods of this class.
     */
    public static class ClientHandler extends Object
    {
        /**
         * Constructor.
         */
        public ClientHandler()
        {
        }
        
        /**
         * Test invocation.
         * 
         * @return result string
         */
        public String testInvocation()
        {
            System.out.println("ClientHandler#testInvocation()");
            
            // emulate time spent for method execution
            try
            {
                Thread.sleep(1000);
            }
            catch (Exception e) {}
            
            return "ClientHandler#testInvocation() result";
        }
    }
    
    /**
     * <code>NetConnectionListener</code> - {@link NetConnection} listener implementation.
     */
    public static class NetConnectionListener extends NetConnection.ListenerAdapter
    {
        /**
         * Constructor.
         */
        public NetConnectionListener()
        {
        }
        
        @Override
        public void onAsyncError(final INetConnection source, final String message, final Exception e)
        {
            System.out.println("NetConnection#onAsyncError: " + message + " " + e);
        }
        
        @Override
        public void onIOError(final INetConnection source, final String message)
        {
            System.out.println("NetConnection#onIOError: " + message);
        }
        
        @Override
        public void onNetStatus(final INetConnection source, final Map<String, Object> info)
        {
            System.out.println("NetConnection#onNetStatus: " + info);
            
            final Object code = info.get("code");
            
            if (NetConnection.CONNECT_SUCCESS.equals(code))
            {
                source.call("testConnection", new Responder()
                {
                    public void onResult(final Object result)
                    {
                        System.out.println("Method testConnection result: " + result);
                    }
                    
                    public void onStatus(final Map<String, Object> status)
                    {
                        System.out.println("Method testConnection status: " + status);
                    }
                });
            }
        }
    }
    
    /**
     * Constructor.
     */
    private ExCreateNetConnection()
    {
    }
}