/**
 * Copyright (c) 2006 - 2008 Smaxe Ltd (www.smaxe.com).
 * All rights reserved.
 */

import com.smaxe.uv.client.INetConnection;
import com.smaxe.uv.client.ISharedObject;
import com.smaxe.uv.client.License;
import com.smaxe.uv.client.NetConnection;
import com.smaxe.uv.client.SharedObject;

import java.util.List;
import java.util.Map;

/**
 * <code>ExConnectRemoteSharedObject</code> - {@link NetConnection} usage example.
 * <p> Note: The example shows how to connect to the remote shared object, set shared
 * object values.
 * 
 * @author Andrei Sochirca
 */
public final class ExConnectRemoteSharedObject extends Object
{
    /**
     * Entry point.
     * 
     * @param args
     */
    public static void main(final String[] args)
    {
        // NOTE:
        // you can get Evaluation Key at:
        // http://www.smaxe.com/order.jsf#request_evaluation_key
        // or buy at:
        // http://www.smaxe.com/order.jsf
        License.setKey("SET-YOUR-KEY");
        
        ExConnectRemoteSharedObject app = new ExConnectRemoteSharedObject();
        
        app.start();
    }
    
    /**
     * <code>NetConnectionListener</code> - {@link NetConnection} listener implementation.
     */
    public class NetConnectionListener extends NetConnection.ListenerAdapter
    {
        /**
         * Constructor.
         */
        public NetConnectionListener()
        {
        }
        
        @Override
        public void onAsyncError(final INetConnection source, final String message, final Exception e)
        {
            System.out.println("NetConnection#onAsyncError: " + message + " " + e);
        }
        
        @Override
        public void onIOError(final INetConnection source, final String message)
        {
            System.out.println("NetConnection#onIOError: " + message);
        }
        
        @Override
        public void onNetStatus(final INetConnection source, final Map<String, Object> info)
        {
            System.out.println("NetConnection#onNetStatus: " + info);
            
            final Object code = info.get("code");
            
            if (NetConnection.CONNECT_SUCCESS.equals(code))
            {
            }
            else
            {
                disconnected = true;
            }
        }
    }
    
    
    // fields
    private volatile boolean disconnected = false;
    
    /**
     * Constructor.
     */
    public ExConnectRemoteSharedObject()
    {
    }
    
    /**
     * Starts the example.
     */
    public void start()
    {
        final NetConnection connection = new NetConnection();
        
        connection.addEventListener(new NetConnectionListener());
        
        connection.connect("rtmp://localhost:1935/app");
        
        // wait till connected
        while (!connection.connected() && !disconnected)
        {
            try
            {
                Thread.sleep(100);
            }
            catch (Exception e) {/*ignore*/}
        }
        
        if (!disconnected)
        {
            SharedObject so = new SharedObject("mySharedObject");
            
            so.addEventListener(new SharedObject.ListenerAdapter()
            {
                @Override
                public void onSync(ISharedObject source, final List<ISharedObject.Change> changeList)
                {
                    for (ISharedObject.Change change : changeList)
                    {
                        switch (change.code)
                        {
                            case ISharedObject.Change.CONNECT:
                            {
                                System.out.println("SharedObject " + source.getName() + " : " + "connected");
                                
                                source.data().put("attr1", 123);
                                
                            } break;
                            case ISharedObject.Change.CHANGE:
                            {
                                System.out.println("SharedObject " + source.getName() + " : " +
                                        "attribute " + change.attribute + " changed from " + change.oldValue + " to " + change.newValue);
                            } break;
                        }
                    }
                }
            });
            
            so.connect(connection, so.getName());
        }
        
        while (!disconnected)
        {
            try
            {
                Thread.sleep(100);
            }
            catch (Exception e) {/*ignore*/}
        }
        
        connection.close();
    }
}