/**
 * Copyright (c) 2006 - 2008 Smaxe Ltd (www.smaxe.com).
 * All rights reserved.
 */

import com.smaxe.uv.client.INetConnection;
import com.smaxe.uv.client.INetStream;
import com.smaxe.uv.client.License;
import com.smaxe.uv.client.NetConnection;
import com.smaxe.uv.client.NetStream;
import com.smaxe.uv.client.video.FlvVideo;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * <code>RtmpStreamDownloader</code> - RTMP stream downloader implementation
 * based on {@link NetConnection}.
 * 
 * @author Andrei Sochirca
 */
public final class RtmpStreamDownloader extends Object
{
    /**
     * Entry point.
     * 
     * @param args
     * @throws Exception if an exception occured
     */
    public static void main(final String[] args) throws Exception
    {
        // NOTE:
        // you can get Evaluation Key at:
        // http://www.smaxe.com/order.jsf#request_evaluation_key
        // or buy at:
        // http://www.smaxe.com/order.jsf
        License.setKey("SET-YOUR-KEY");
        
        RtmpStreamDownloader downloader = new RtmpStreamDownloader();
        
        final boolean result = downloader.download("rtmp://localhost:1935/live", "stream", "stream.flv");
        
        System.out.println("=> " + result);
    }
    
    
    /**
     * <code>NetConnectionListener</code> - {@link NetConnection} listener.
     */
    private class NetConnectionListener extends NetConnection.ListenerAdapter
    {
        // fields
        private FlvVideo flvVideo = null;
        private String stream = null;
        
        /**
         * Constructor.
         * 
         * @param stream stream to play
         * @param file file
         * @throws Exception 
         */
        public NetConnectionListener(final String stream, final String file) throws Exception
        {
            this.flvVideo = new FlvVideo(file, -512 * 1024 /*buffer size*/, false /*sync*/);
            this.stream = stream;
        }
        
        @Override
        public void onAsyncError(final INetConnection source, final String message, final Exception e)
        {
            System.out.println("NetConnection#onAsyncError: " + message + " " + e);
            
            disconnected = true;
        }
        
        @Override
        public void onIOError(final INetConnection source, final String message)
        {
            System.out.println("NetConnection#onIOError: " + message);
            
            disconnected = true;
        }
        
        @Override
        public void onNetStatus(final INetConnection source, final Map<String, Object> info)
        {
            System.out.println("NetConnection#onNetStatus: " + info);
            
            final Object code = info.get("code");
            
            if (NetConnection.CONNECT_SUCCESS.equals(code))
            {
                dispatcher.execute(new Runnable()
                {
                    public void run()
                    {
                        final NetStream netStream = new NetStream(source);
                        
                        netStream.addEventListener(new NetStream.ListenerAdapter()
                        {
                            @Override
                            public void onNetStatus(final INetStream source, final Map<String, Object> info)
                            {
                                System.out.println("NetStream#onNetStatus: " + info);
                                
                                final String code = (String) info.get("code");
                                
                                if (NetStream.PLAY_START.equals(code))
                                {
                                }
                                else
                                if (NetStream.PLAY_STOP.equals(code) || NetStream.PLAY_UNPUBLISH_NOTIFY.equals(code))
                                {
                                    netStream.close();
                                    
                                    flvVideo.release();
                                    
                                    downloaded = true;
                                    disconnected = true;
                                }
                            }
                        });
                        
                        netStream.play(flvVideo, stream);
                    }
                });
            }
            else
            if (NetConnection.CONNECT_FAILED.equals(code))
            {
                disconnected = true;
            }
        }
    }
    
    // fields
    private boolean disconnected = false;
    private boolean downloaded = false;
    
    private ExecutorService dispatcher = null;
    
    /**
     * Constructor.
     */
    private RtmpStreamDownloader()
    {
    }
    
    /**
     * Downloads <code>stream</code> from the <code>url</code> and
     * saves it to the <code>file</code>.
     * 
     * @param url
     * @param stream
     * @param file
     * @return <code>true</code> if succeeded to download; otherwise <code>false</code>
     * @throws Exception 
     */
    public boolean download(final String url, final String stream, final String file) throws Exception
    {
        dispatcher = Executors.newSingleThreadExecutor();
        
        final NetConnection connection = new NetConnection();
        
        connection.addEventListener(new NetConnectionListener(stream, file));
        
        connection.connect(url);
        
        while (!disconnected)
        {
            try
            {
                Thread.sleep(100);
            }
            catch (Exception e) {/*ignore*/}
        }
        
        connection.close();
        
        dispatcher.shutdown();
        
        return downloaded;
    }
}