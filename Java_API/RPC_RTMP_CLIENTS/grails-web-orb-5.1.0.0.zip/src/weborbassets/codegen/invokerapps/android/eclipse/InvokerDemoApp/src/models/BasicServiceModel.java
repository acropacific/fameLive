package models;

/**
 * Created by IntelliJ IDEA.
 * User: Yuri Samsoniuk
 * Date: 4/26/11
 * Time: 2:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class BasicServiceModel {
}
