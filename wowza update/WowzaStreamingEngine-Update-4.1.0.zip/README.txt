========================================
Changes in Wowza Streaming Engine 4.1.0 Build 12602

	* Modified the Linux services code for stop and start rather then returning a status code as they have in the past. They will now return 0 for both stop and start. The status call will return a 0 for running and 3 for not running.
    * Added long property scalerMainConceptScaleMode available in Encoder/Properties to control the scale mode used in transcoder (0 = nearest neighbour, 1 = best (default), 2 = bilinear, 3 = polyphase8)
    * Added support in transcoder for double rate deinterlacing of H.264, MP2 and MP4 streams (enabled by adding long parameter with the name deinterlaceDoubleRate with a value of 1 to the Decode/Video/Parameters section of transcoder template, off by default)
    * Made SHOUTcast AAC group count property shoutcastAACGroupCount available in Streaming Engine Manager
    * Changed SHOUTcast default MP3 and AAC group count (shoutcastMP3GroupCount and shoutcastAACGroupCount) to 1 (previous value was 4)
    * Improved parsing of SCC caption files, allowing multiple whitespace characters between fields
    * Fixed problem with HEVC/H.265 VPS decoding leading to warning message about multiple VPS NAL units
    * Enhanced debug context for DVR MBR alignment logging to include aligner ID
    * Fixed problem with transcoder multi-threaded scaling throwing an error if only a single encoder output
    * Improved transcoder system to properly shutdown transcoder (and release license) when stream source is push publisher
    * Added Streams/Propertries boolean property transcoderShutdownOnClose to control when transcoder is shutdown (true: transcoder is shutdown when stream is closed, false: transcoder is shutdown when stream is destroyed, default to false except when source stream is push publisher)
    * Added some exception handling in the PushPublishing module where HTTP streams are being pushed to an endpoint
    * Updated colors to match between the protocol pie chart and the historic chart on the VHost and Application monitoring pages
    * Exposed the default value for securityPublishValidEncoders as "Flash Version String" in the Manager so users can replace or append to the list of allowed values
    * Fixed a PushPublishing cupertino-akamai bug that was keeping WSE from sending the HLS playlist file to akamai
    * Changed the default setting for importing AC3 streams via MPEG-TS to true
    * Fixed case where DVR ABR would not align correctly after packet time reset mid recording. This could sometimes result in segments of the DVR out of order or longer than expected playlists
    * Fixed an issue with reading the MPEG-TS PMT Stream Descriptors and the detection of AC3 streams
    * Changed parsing of flash version string to allow either pipe or comma delimiters   
    * Fixed PushPublishing HLS bug where an occasional race condition would cause an exception in the HLS chunk processing, which would cause a chunk to never get pushed to the destination
    * Fixed logic around selecting the correct vhost port for the test players in Streaming Engine Manager
    * Fixed issue where HLS AES encryption using smil files would not return correct internal encryption key
    * Added an MPEG-TS property mpegtsRemoveRepeatStartCodes that can be set to remove start codes that are repeated in the stream
    * Turned importing AC3 back to "false" as the default because we don't support AC3 in the transcoder.  We are concerned that this can adversely affect customers that have MPEG-TS streams with AC3 streams before their other audio streams in the PMT and we'll pickup the AC3 as the default
    * Fixed PushPublishing memory leak that would occur on every stream disconnect
    * Fixed PushPublishing RTMP connection logic so that all reconnection attempts always occur with a gradually increasing delay (up to 60 sec) between each attempt,  the same way it has historically worked for the initial RTMP tcp connection
    * Added support for enabling the HbbTV-specific live MPEG-DASH manifest profile definition using the mpegdashEnableHbbtvLiveProfile property
            
========================================
Changes in Wowza Streaming Engine 4.0.6.01 Build 12338

    * Added HEVC/H.265 encoder and decoder support to transcoder (preview)
    * Added support for HEVC/H.265 stream ingestion and playback over MPEG-TS (preview)
    * Added support for HEVC/H.265 stream ingestion and playback over RTP (preview)
    * Added support for recording HEVC/H.265 to MP4 files (preview)
    * Fixed CurrentIncomingStreamStatistics for liveRepeaters so that LiveRepeater Incoming streams on the edge correctly report Bytes In instead of always showing 0
    * Updated PushPublishing rtmp-akamai profile so that when a map entry provides a streamName with more than 2 "_" characters, we remove the first "_" character. So "my_stream_1_2728@123456" becomes "mystream_1_2728@123456". 
    * Fixed the error message presented to the user when they enter an invalid value in the Server->Performance Tuning->Virtual Hosts Ports->Processor Count fields of the Wowza Streaming Engine Manager.
    * Fixed a bug in ModuleDRMVerimatrix for Playready DRM which prevented server from sending a request for a Playready key.
    * Fixed logging in ModuleDRMVerimatrix which logged a DASH URL when playing back with SmoothStreaming
    * Fixed the return content type for some JSON calls which caused Chrome on iOS devices to crash or otherwise not load the WSE Manager correctly
    * Fixed WSEM testplayer logic to use a non vhost ssl port if one exists
    * Removed debug print statement in live receiver for RTMP events
    * Reverted Fix for live repeater statistics because it causes an exception on the manager side of the REST interface
    * Fixed closed caption bug where captions were not returned when using a smil file and specifying either system language and/or title in the audio or video renditions 
    * Fixed issue where CC file specified in smil file was relative to content folder instead of relative to smil file location    
    * Removed verbose DVR Recorder timeout logging message
    * Enhanced CEA-608 parser to capture the raw commands as well as the text of converted caption 
    * Fixed problem where .scc caption files were not displaying on HLS when streaming CEA-608 
    * Changed RTSP authentication to use either Application level properties "securityPublishPasswordFile" or "rtspEncoderAuthenticateFile" to find password file
    * Changed RTMP to allow either Application level properties "securityPublishPasswordFile" or "rtmpEncoderAuthenticateFile" to find password file
    * Fixed issue with getDataMissing in LiveReceiver where it could return a NullPointerException
    * Fixed transcoder so it only suspends key frame skipping on key frames if encode is keyFrameFollow
    * Fixed stuttered playback when playing HDS VOD with captions inserted
    * Fixed a bug during application copy process in Wowza Streaming Engine Manager where application wasn't given the new name in conf/[newAppName]/Applilcation.xml under the Name tag
    * Fixed a bug in Wowza Streaming Engine Manager where the Copy button wasn't copying an application due to dysfunctional buttons. This was happening on SMIL Files, Stream Files and Transcoder Addon pages
    * Fixed a corner case bug in Wowza Streaming Engine Manager where a form was being submitted even if errors existed on several incoming publishers pages
        
========================================
