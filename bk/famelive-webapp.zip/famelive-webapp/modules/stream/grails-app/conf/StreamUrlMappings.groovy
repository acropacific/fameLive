class StreamUrlMappings {

    static mappings = {
        "/" {
            controller = 'streamingAdmin'
            action = 'index'
        }
    }
}
