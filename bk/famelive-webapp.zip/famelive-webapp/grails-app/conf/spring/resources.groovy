// Place your Spring DSL code here
/*boolean containsPlugin(String pluginName) {
    def names = org.codehaus.groovy.grails.plugins.PluginManagerHolder.pluginManager.allPlugins.collect { it -> return it.name }
    return (pluginName in names)
}*/

beans = {

    /*mailService(MandrillMailService) {
        grailsApp = ref('grailsApplication')
    }*/

}
